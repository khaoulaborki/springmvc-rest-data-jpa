package ma.formations.springmvcrestdatajpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringmvcRestDataJpaApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringmvcRestDataJpaApplication.class, args);
    }

}
